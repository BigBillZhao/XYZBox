/* SPDX-License-Identifier: GPL-2.0 */
/*
 * kcan_usb_core.h - the outer usb parts header for all KCAN USB interfaces
 *                   support
 *
 * Copyright (C) 2022-2026 Chengdu Kunhong Electronic Technology Co., Ltd <www.kunhong-elec.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Contact:      <support@cdkhdz.com>
 * Maintainer:   Kunhong-Elec driver team <gene@cdkhdz.com>
 */
#ifndef __KCAN_USB_CORE_H__
#define __KCAN_USB_CORE_H__

#include <src/kcan_main.h>

/* External API */
#ifdef __cplusplus__
extern "C" {
#endif

int kcan_usb_register_devices(void);
void kcan_usb_deinit(void);

#ifdef __cplusplus__
};
#endif

#endif
