from typing_extensions import Literal

from ....piper.versions.v183.driver import Driver as PiperDriverV183


class Driver(PiperDriverV183):
    """
    PiperX CAN driver for firmware v183~v187 (S-V1.8-3 ~ S-V1.8-7).

    Terminology
    -----------
    `flange`:
    - The mounting face / connection interface on the robotic arm's last link
      (mechanical tool interface).

    Common conventions
    ------------------
    `timeout` (for request/response style APIs):
    - `timeout < 0.0` raises ValueError.
    - `timeout == 0.0`: non-blocking; evaluate readiness once and return
      immediately.
    - `timeout > 0.0`: blocking; poll until ready or timeout expires.

    `joint_index`:
    - `joint_index == 255` means "all joints".

    `set_*` return semantics:
    - Many `set_*` APIs are ACK-only: True means the controller acknowledged the
      request, but it does not strictly guarantee the setting is already applied.
    - Some `set_*` APIs additionally verify by reading back state; their
      docstrings will mention the verification method if applicable.
    """

    def move_cpv_pos(
        self,
        joint_index: Literal[1, 2, 3, 4, 5, 6],
        pos: float,
    ) -> None:
        """Command joint position in CPV motion mode.

        Parameters
        ----------
        `joint_index`: Literal[1, 2, 3, 4, 5, 6]

        `pos`: float
        - Target joint angle in radians.
        """
        # TODO: remove this after the bug is fixed
        if joint_index in [4, 5]:
            pos = -pos
        super().move_cpv_pos(
            joint_index,
            pos,
        )

    def move_cpv_vel(
        self,
        joint_index: Literal[1, 2, 3, 4, 5, 6],
        vel: float,
    ) -> None:
        """Command joint velocity reference in CPV motion mode.

        Parameters
        ----------
        `joint_index`: Literal[1, 2, 3, 4, 5, 6]

        `vel`: float
        - Desired joint velocity in rad/s.
        """
        # TODO: remove this after the bug is fixed
        if joint_index in (2, 3):
            vel *= -1
        self._move_cpv(
            joint_index=joint_index,
            type_='sp',
            value=vel,
        )
